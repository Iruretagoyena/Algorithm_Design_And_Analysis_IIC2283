docker run -v ${PWD}:/app -e part=p2 algoritmos
