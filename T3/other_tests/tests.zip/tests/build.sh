docker build -t algoritmos tests
