docker run -v ${PWD}:/app -e part=p1 algoritmos
